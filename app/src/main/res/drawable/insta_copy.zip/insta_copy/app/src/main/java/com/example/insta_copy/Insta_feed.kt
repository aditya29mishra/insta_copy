package com.example.insta_copy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class Insta_feed : Fragment() {
    private var layoutManager:RecyclerView.LayoutManager? = null
    private var adapter1: RecyclerView.Adapter<FeedAdapter.FeedViewHolder>? = null
    private var adapter2: RecyclerView.Adapter<StoryAdapter.StoryViewholder>? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_insta_feed, container, false)
    }
    override fun onViewCreated(itemView: View, savedInstanceState: Bundle?) {
        super.onViewCreated(itemView, savedInstanceState)
        feedRecycle.apply {

            layoutManager = LinearLayoutManager(activity)
            adapter1 = FeedAdapter()
        }
        storyRecycle.apply {

            layoutManager = LinearLayoutManager(activity)
            adapter2 = StoryAdapter()
        }

    }
}